package ca.mcgill.ecse321.HomeAudioSystem.view;

public enum Genre 
{
	Rock,
	HipHop,
	Pop,
	Country,
	Dance,
	Electronic,
	Jazz,
	Classical,
	House,
	Others
}
